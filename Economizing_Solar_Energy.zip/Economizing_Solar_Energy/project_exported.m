classdef project_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                      matlab.ui.Figure
        TabGroup                      matlab.ui.container.TabGroup
        IntrotabandexplanationTab     matlab.ui.container.Tab
        TextArea_3                    matlab.ui.control.TextArea
        TextArea                      matlab.ui.control.TextArea
        AresolarpanelsrightforyouTab  matlab.ui.container.Tab
        DropDown_3                    matlab.ui.control.DropDown
        PlotThisTableButton_2         matlab.ui.control.Button
        Image2_2                      matlab.ui.control.Image
        FormulaForLineofBestFitTextArea_2  matlab.ui.control.TextArea
        FormulaForLineofBestFitTextArea_2Label  matlab.ui.control.Label
        UIAxes                        matlab.ui.control.UIAxes
        SolarPVinstallationcostpercountryTab  matlab.ui.container.Tab
        DisplayMaxButton              matlab.ui.control.Button
        DisplayMinButton              matlab.ui.control.Button
        SelectCountryDropDown         matlab.ui.control.DropDown
        SelectCountryDropDownLabel    matlab.ui.control.Label
        UIAxes2                       matlab.ui.control.UIAxes
        AnnualUitilityScalePVcapacityTab  matlab.ui.container.Tab
        SelectModuleandormountingtypeDropDown  matlab.ui.control.DropDown
        SelectModuleandormountingtypeDropDownLabel  matlab.ui.control.Label
        PlotavgAnnualCapacityButton   matlab.ui.control.Button
        UIAxes_2                      matlab.ui.control.UIAxes
        AngleofSolarPanelvsTimeofDayTab  matlab.ui.container.Tab
        CityDropDown                  matlab.ui.control.DropDown
        CityDropDownLabel             matlab.ui.control.Label
        StateDropDown                 matlab.ui.control.DropDown
        StateDropDownLabel            matlab.ui.control.Label
        UIAxes3                       matlab.ui.control.UIAxes
        citationsTab                  matlab.ui.container.Tab
        TextArea_2                    matlab.ui.control.TextArea
        YearDropDown                  matlab.ui.control.DropDown
        YearDropDownLabel             matlab.ui.control.Label
        MonthDropDown                 matlab.ui.control.DropDown
        MonthDropDownLabel            matlab.ui.control.Label
        DayDropDown                   matlab.ui.control.DropDown
        DayDropDownLabel              matlab.ui.control.Label
        TextArea_Sunrise              matlab.ui.control.TextArea
        TextArea_Sunrise_Label        matlab.ui.control.Label
        TextArea_Sunset               matlab.ui.control.TextArea
        TextArea_Sunset_Label         matlab.ui.control.Label
    end


    properties (Access = private)
        xprice
        ysize
        ywatts

    end



    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: PlotThisTableButton_2
        function PlotDataButtonPushed(app, event)


            app.ysize= [2534.74, 2588.58, 2553.23, 2585.9475, 3368.5, 3123.22, 3018.52, 3118.9];
            app.xprice= [265, 262, 190, 345, 464, 311, 317, 320];
            app.ywatts=[360, 305, 335, 310, 450, 400, 415, 405];
            %The above lines of code are loading my data into the values that they
            %coorespond with.
            scatter(app.UIAxes,app.xprice,app.ysize,80, "filled", "rd")
            hold(app.UIAxes, "on"); % This creates a scatter of my price vs size data
            scatter(app.UIAxes,app.xprice,app.ywatts,80, "filled", "bd")% This creates a scatter of my price vs wattage data
            grid (app.UIAxes, "on")
            xlabel(app.UIAxes, "price")
            ylabel(app.UIAxes, "size and watts")
            % these above lines just provide formatting
            axis(app.UIAxes,[min(app.xprice)*.9, max(app.xprice)*1.1, min(app.ywatts)*.9, max(app.ysize)*1.1])
            hold(app.UIAxes, "off");
            legend(app.UIAxes, "Size values", "Watts Values") % This turns on a legend that displays both of the values included
        end

        % Callback function: DropDown_3, DropDown_3, DropDown_3,
        % ...and 2 other components
        function DropDownValueChanged(app, event)
            TYPE = app.DropDown_3.Value;


            app.xprice= [265, 262, 190, 345, 464, 311, 317, 320];
            app.ywatts=[360, 305, 335, 310, 450, 400, 415, 405];
            % Again storing data in price and watts values.
            scatter(app.UIAxes,app.xprice,app.ywatts,80, "filled", "bd")
            grid (app.UIAxes, "on")
            xlabel(app.UIAxes, "price")
            ylabel(app.UIAxes, "watts")
            axis(app.UIAxes,[min(app.xprice)*.9, max(app.xprice)*1.1, min(app.ywatts)*.9, max(app.ywatts)*1.1])
            %Plot formatting above to make the axis good and have a grid and
            %labels
            if strcmpi(TYPE, "price vs wattage")==1
                %If statement that cooresponds with drop down value
                bruh = polyfit(app.xprice, app.ywatts, 1);
                m = bruh(1);
                b = bruh(2);
                pricewatts = @(q) m*q + b;
                yipee = sprintf("y = %.4fx + %.4f", m, b);
                % The above code makes the formula for the line of best fit and displays
                % it.

                app.FormulaForLineofBestFitTextArea_2.Value = yipee;
                %This is how it gets displayed.
                hold (app.UIAxes, "on" )
                fplot(app.UIAxes, pricewatts, [min(app.xprice),max(app.ywatts)],'-r')
                hold(app.UIAxes, "off" )

                legend(app.UIAxes, "Wattage values", "Regression Line")

                %hold on and off functions to make sure that values change if you switch
                %dropdown value. And the legend lapes wattage values and regression line to
                %elements on the graph.

            elseif  strcmpi(TYPE, "price vs size")==1

                app.xprice= [265, 262, 190, 345, 464, 311, 317, 320];
                app.ysize= [2534.74, 2588.58, 2553.23, 2585.9475, 3368.5, 3123.22, 3018.52, 3118.9];
                scatter(app.UIAxes,app.xprice,app.ysize,80, "filled", "bd")
                grid (app.UIAxes, "on")
                xlabel(app.UIAxes, "price")
                ylabel(app.UIAxes, "size")
                axis(app.UIAxes,[min(app.xprice)*.9, max(app.xprice)*1.1, min(app.ysize)*.9, max(app.ysize)*1.1])
                %All this is same as above except we now are displaying price vs
                %size values on the graph.

                bruh = polyfit(app.xprice, app.ysize, 1);
                m = bruh(1);
                b = bruh(2);
                pricesize = @(q) m*q + b;
                yipee = sprintf("y = %.4fx + %.4f", m, b);

                % again same as before but using our new values.
                app.FormulaForLineofBestFitTextArea_2.Value = yipee;

                hold (app.UIAxes, "on" )
                fplot(app.UIAxes, pricesize, [min(app.xprice),max(app.ysize)],"-r")
                hold(app.UIAxes, "off" )
                legend(app.UIAxes, "Size values", "Regression Line")

                %Once again uses hold on and hold off and then changes the legend so
                %size values and regression line are shown in the legend.
            end
        end

        % Callback function
        function LoadDataButtonPushed(app, event)

        end

        % Value changed function: SelectCountryDropDown
        function SelectCountryDropDownValueChanged(app, event)
            %Alex Daquinag
            TYPE = app.SelectCountryDropDown.Value;
            %TYPE is a variable for each drop down option so that I can use it to identify each option in strcmpi

            if strcmpi(TYPE, "United States") == 1 % if TYPE equals the string for the country I want to plot, run loop for plotting
                labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"]; % string values for the labels on the x-axis of our bar graph
                numbers = [358.1+68.4, 113.7+61.8+42.5+18.7+16.6, 180.2+68.3+21.4, 173.3+19.8+22.8+8.9+38.6+7.5]; %array of lengths of the
                bar(app.UIAxes2, numbers)
                xticks(app.UIAxes2, 1:length(labels)) % xticks(ticks) sets the x-axis tick values. sets the number of ticks equal to the length of "labels" variable
                xticklabels(app.UIAxes2, labels) % xtickslabels(ticks) sets the x-axis tick labels. I have it set to the labels string array

                for i = 1:length(numbers) %loop that moves to the next bar in the bar graph for the number of bars present
                    text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom') % puts the number value of each bar in the graph above the bar
                    box(app.UIAxes2, "off") %removes the box outline in the axes for visibility purposes
                end

                ylim(app.UIAxes2,[0 800]) %sets a y axis limit for visible consistency readability purposes
                title(app.UIAxes2,'Total Solar PV Installation Cost (United States)') % changes the title according to the dropdown selected
            end

            %COMMENTS FOR THE CODE ABOVE APPLY TO ALL INSTANCES OF THE DROP DOWN MENU BELOW

            if strcmpi(TYPE, "Russian Federation") == 1
                labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"];
                numbers = [399.4+100, 109.6+192.5+78.5+21.9+15.2, 230.5+215.6+26.8, 212.8+156.6+65.7+192.7+84.6+14.4];

                bar(app.UIAxes2, numbers)
                xticks(app.UIAxes2, 1:length(labels))
                xticklabels(app.UIAxes2, labels)

                for i = 1:length(numbers)
                    text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom')
                    box(app.UIAxes2, "off")
                end
                ylim(app.UIAxes2,[0 800])
                title(app.UIAxes2,'Total Solar PV Installation Cost (Russia)')
            end

            if strcmpi(TYPE, "Japan") == 1
                labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"];
                numbers = [450.8+223.7, 116.5+112.1+69.9+19.9+18.1, 456.2+292.1+34.7, 123.7+63.5+5.1+50.2+27.2+6.2];

                bar(app.UIAxes2, numbers)
                xticks(app.UIAxes2, 1:length(labels))
                xticklabels(app.UIAxes2, labels)

                for i = 1:length(numbers)
                    text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom')
                    box(app.UIAxes2, "off")
                end
                ylim(app.UIAxes2,[0 800])
                title(app.UIAxes2,'Total Solar PV Installation Cost (Japan)')
            end

            if strcmpi(TYPE, "Canada") == 1
                labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"];
                numbers = [554.1+69.1, 118.3+92.3+39.3+17.2+5.2, 125.7+42.0+7.6, 202+13.3+75.4+7.5+21.7+13.2];

                bar(app.UIAxes2, numbers)
                xticks(app.UIAxes2, 1:length(labels))
                xticklabels(app.UIAxes2, labels)

                for i = 1:length(numbers)
                    text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom')
                    box(app.UIAxes2, "off")
                end
                ylim(app.UIAxes2,[0 800])
                title(app.UIAxes2,'Total Solar PV Installation Cost (Canada)')
            end

            if strcmpi(TYPE, "South Africa") == 1
                labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"];
                numbers = [557.0+89.8, 108.5+53.4+47.8+22.7+25.3, 46.1+31.4+3.3, 104+60.6+79.5+58.1+18.8+14.8];

                bar(app.UIAxes2, numbers)
                xticks(app.UIAxes2, 1:length(labels))
                xticklabels(app.UIAxes2, labels)

                for i = 1:length(numbers)
                    text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom')
                    box(app.UIAxes2, "off")
                end
                ylim(app.UIAxes2,[0 800])
                title(app.UIAxes2,'Total Solar PV Installation Cost (South Africa)')
            end

            if strcmpi(TYPE, "Argentina") == 1
                labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"];
                numbers = [340+91.7, 78.1+95.2+67.4+12.6+9.4, 84.3+101+10.6, 144.2+110.6+9.9+122.4+29.8+4.8];

                bar(app.UIAxes2, numbers)
                xticks(app.UIAxes2, 1:length(labels))
                xticklabels(app.UIAxes2, labels)

                for i = 1:length(numbers)
                    text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom')
                    box(app.UIAxes2, "off")
                end
                ylim(app.UIAxes2,[0 800])
                title(app.UIAxes2,'Total Solar PV Installation Cost (Argentina)')
            end

            if strcmpi(TYPE, "United Kingdom") == 1
                labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"];
                numbers = [362.2+54.8, 47.2+62.1+39.7+14.4+5.9, 98.3+73.0+12.2, 63.1+66.0+17.5+69.4+28.0+3.7];

                bar(app.UIAxes2, numbers)
                xticks(app.UIAxes2, 1:length(labels))
                xticklabels(app.UIAxes2, labels)

                for i = 1:length(numbers)
                    text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom')
                    box(app.UIAxes2, "off")
                end
                ylim(app.UIAxes2,[0 800])
                title(app.UIAxes2,'Total Solar PV Installation Cost (United Kingdom)')
            end

        end

        % Button pushed function: PlotavgAnnualCapacityButton
        function PlotavgAnnualCapacityButtonPushed(app, event)
            gdata=readmatrix("pv data.xlsx");%loading in data
            bar_data=gdata(22:33,2); %bringing in the average annual capacity
            bar(app.UIAxes_2,bar_data)
            grid (app.UIAxes_2,"on")
            set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})%year
            xlabel(app.UIAxes_2,'Installation Year')%the x axi
            ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
            title(app.UIAxes_2,'Average Annual Capacity ')%title

        end

        % Value changed function: SelectModuleandormountingtypeDropDown
        function typeSelected(app, event)
            value = app.SelectModuleandormountingtypeDropDown.Value;
            gdata=readmatrix("pv data.xlsx");%loading in data
            if strcmpi("Tracking Thin-Film",value)% creating each plot for drop down menu
                bar_data=gdata(6:17,12);
                bar(app.UIAxes_2,bar_data)
                grid (app.UIAxes_2,"on")
                set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})
                xlabel(app.UIAxes_2,'Installation Year')%the x axi
                ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
                title(app.UIAxes_2,'Tracking Thin-Film')%title
            elseif strcmpi("Tracking c-Si",value)
                bar_data=gdata(6:17,4);
                bar(app.UIAxes_2,bar_data)
                grid (app.UIAxes_2,"on")
                set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})
                xlabel(app.UIAxes_2,'Installation Year')%the x axi
                ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
                title(app.UIAxes_2,'Tracking c-Si')%title
            elseif strcmpi("Fixed-Tilt Thin-Film",value)
                bar_data=gdata(6:17,16);
                bar(app.UIAxes_2,bar_data)
                grid (app.UIAxes_2,"on")
                set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})
                xlabel(app.UIAxes_2,'Installation Year')%the x axi
                ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
                title(app.UIAxes_2,'Fixed-Tilt Thin-Film')%title
            elseif strcmpi("Fixed-Tilt c-Si",value)
                bar_data=gdata(6:17,8);
                bar(app.UIAxes_2,bar_data)
                grid (app.UIAxes_2,"on")
                set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})
                xlabel(app.UIAxes_2,'Installation Year')%the x axi
                ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
                title(app.UIAxes_2,'Fixed-Tilt c-Si')%title
            elseif strcmpi("Total Thin-Film",value)
                bar_data=gdata(6:17,32);
                bar(app.UIAxes_2,bar_data)
                grid (app.UIAxes_2,"on")
                set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})
                xlabel(app.UIAxes_2,'Installation Year')%the x axi
                ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
                title(app.UIAxes_2,'Total Thin-Film')%title
            elseif strcmpi("Total c-Si",value)
                bar_data=gdata(6:17,28);
                bar(app.UIAxes_2,bar_data)
                grid (app.UIAxes_2,"on")
                set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})
                xlabel(app.UIAxes_2,'Installation Year')%the x axi
                ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
                title(app.UIAxes_2,'Total c-Si')%title
            elseif strcmpi("Total Fixed-Tilt",value)
                bar_data=gdata(6:17,24);
                bar(app.UIAxes_2,bar_data)
                grid (app.UIAxes_2,"on")
                set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})
                xlabel(app.UIAxes_2,'Installation Year')%the x axi
                ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
                title(app.UIAxes_2,'Total Fixed-Tilt')%title
            elseif  strcmpi("Total Tracking",value)
                bar_data=gdata(6:17,19);
                bar(app.UIAxes_2,bar_data)
                grid (app.UIAxes_2,"on")
                set(app.UIAxes_2, 'XTickLabel',{'2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022'})
                xlabel(app.UIAxes_2,'Installation Year')%the x axi
                ylabel(app.UIAxes_2,'Annual Capacity Additions (GWAC)')% the y axi
                title(app.UIAxes_2,'Total Tracking')%title

            end





        end

        % Callback function
        function gg(app, event)
            item = event.InteractionInformation.Item;

        end

        % Callback function
        function PlotThisTableButton_2Pushed(app, event)

        end

        % Button pushed function: DisplayMinButton
        function DisplayMinButtonPushed(app, event)
            %Alex Daquinag
            %when this button is pushed, it plots the minimum values of cost installation (hardcoded)
            %graphing process is explained above in the SelectCountryDropDown callback function
            labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"];
            numbers = [362.2+54.8, 47.2+62.1+39.7+14.4+5.9, 98.3+73.0+12.2, 63.1+66.0+17.5+69.4+28.0+3.7];

            bar(app.UIAxes2, numbers)
            xticks(app.UIAxes2, 1:length(labels))
            xticklabels(app.UIAxes2, labels)

            for i = 1:length(numbers)
                text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom')
                box(app.UIAxes2, "off")
            end
            ylim(app.UIAxes2,[0 800])
            title(app.UIAxes2,'Minimum Solar PV Installation Cost (United Kingdom)')%title indicates that the data presented is the minimum data when button pressed
        end

        % Button pushed function: DisplayMaxButton
        function DisplayMaxButtonPushed(app, event)
            %Alex Daquinag
            %when this button is pushed, it plots the maximum values of cost installation (hardcoded)
            %graphing process is explained above in the SelectCountryDropDown callback function
            labels = ["Module and Inverter Hardware","BoS Hardware","Installation", "Soft Costs"];
            numbers = [399.4+100, 109.6+192.5+78.5+21.9+15.2, 230.5+215.6+26.8, 212.8+156.6+65.7+192.7+84.6+14.4];

            bar(app.UIAxes2, numbers)
            xticks(app.UIAxes2, 1:length(labels))
            xticklabels(app.UIAxes2, labels)

            for i = 1:length(numbers)
                text(app.UIAxes2, i, numbers(i), num2str(numbers(i),'%0.2f'), 'HorizontalAlignment','center','VerticalAlignment','bottom')
                box(app.UIAxes2, "off")
            end
            ylim(app.UIAxes2,[0 800])
            title(app.UIAxes2,'Maximum Solar PV Installation Cost (Russia)') %title indicates that the data presented is the maximum data when button pressed
        end
    end

    properties (Access = public)
        databaseStates = readcell('States.csv'); % database with U.S. states
        databaseCities = readcell('uscities.csv'); % database with U.S. cities and their respective latitude and longitudes
        % initializing variables
        ang_vel = 0;
        sunrise = 0;
        sunset = 0;
        solarTime = 0;

    end
    methods (Access = private)
        function StateDropDownValueChanged(app, event)

            % check if state drop down contains a valid input
            if ismember(app.StateDropDown.Value, app.StateDropDown.Items)
                updateCities(app, app.StateDropDown.Value);
            end

            % check if all graph inputs are valid
            if ismember(app.MonthDropDown.Value, app.MonthDropDown.Items) ...
                    && ismember(app.YearDropDown.Value,app.YearDropDown.Items) ...
                    && ismember(app.StateDropDown.Value, app.StateDropDown.Items) ...
                    && ismember(app.CityDropDown.Value, app.CityDropDown.Items)

                % Obtain the appropriate information needed to plot graph
                % and then update graph
                obtainLatitudeAndLongitudeAndDayNumber(app, app.StateDropDown.Value, app.CityDropDown.Value);
                updateGraph(app);
            end

        end
    end

    methods (Access = private)

        % cities show up after state is selected, so the drop down list
        % will change depending on the state
        function updateCities(app, state)
            app.CityDropDown.Items = {''};
            count = 1;

            % check entire databaseCities
            for (i = 1:height(app.databaseCities))

                % if chosen state is equal to state on database,
                % retrieve the corresponding city
                if (isequal(char(state), char(app.databaseCities(i,2))))
                    app.CityDropDown.Items(count) = app.databaseCities(i,1);
                    count = count + 1;
                end
            end
        end
    end

    methods (Access = private)
        function CityDropDownValueChanged(app, event)

            % check if all graph inputs are valid
            if ismember(app.MonthDropDown.Value, app.MonthDropDown.Items) ...
                    && ismember(app.YearDropDown.Value,app.YearDropDown.Items) ...
                    && ismember(app.StateDropDown.Value, app.StateDropDown.Items) ...
                    && ismember(app.CityDropDown.Value, app.CityDropDown.Items)

                % Obtain the appropriate information needed to plot graph
                % and then update graph
                obtainLatitudeAndLongitudeAndDayNumber(app, app.StateDropDown.Value, app.CityDropDown.Value);

                updateGraph(app);


            end

        end
    end

    methods (Access = private)
        function YearDropDownValueChanged(app, event)

            % check if Year and Month contain a valid input
            if ismember(app.MonthDropDown.Value, app.MonthDropDown.Items) ...
                    && ismember(app.YearDropDown.Value, app.YearDropDown.Items)

                % items for the day drop down do not show up until after a
                % month and year is selected. update the day drop down once
                % given essential information
                updateDays(app, app.YearDropDown.Value, app.MonthDropDown.Value);
            end

            % check if all graph inputs are valid
            if ismember(app.MonthDropDown.Value, app.MonthDropDown.Items) ...
                    && ismember(app.YearDropDown.Value,app.YearDropDown.Items) ...
                    && ismember(app.StateDropDown.Value, app.StateDropDown.Items) ...
                    && ismember(app.CityDropDown.Value, app.CityDropDown.Items)

                % Obtain the appropriate information needed to plot graph
                % and then update graph
                obtainLatitudeAndLongitudeAndDayNumber(app, app.StateDropDown.Value, app.CityDropDown.Value);
                updateGraph(app);
            end
        end
    end

    methods (Access = private)
        function MonthDropDownValueChanged(app, event)

            % check if Month drop down and Year drop down contains valid inputs
            if ismember(app.MonthDropDown.Value, app.MonthDropDown.Items) ...
                    && ismember(app.YearDropDown.Value, app.YearDropDown.Items)
                updateDays(app, app.YearDropDown.Value, app.MonthDropDown.Value);
            end

            % check if all graph inputs are valid
            if ismember(app.MonthDropDown.Value, app.MonthDropDown.Items) ...
                    && ismember(app.YearDropDown.Value,app.YearDropDown.Items) ...
                    && ismember(app.StateDropDown.Value, app.StateDropDown.Items) ...
                    && ismember(app.CityDropDown.Value, app.CityDropDown.Items)

                % Obtain the appropriate information needed to plot graph
                % and then update graph
                obtainLatitudeAndLongitudeAndDayNumber(app, app.StateDropDown.Value, app.CityDropDown.Value);
                updateGraph(app);
            end
        end
    end

    methods (Access = private)
        function DayDropDownValueChanged(app, event)

            % check if all graph inputs are valid
            if ismember(app.DayDropDown.Value, app.DayDropDown.Items) ...
                    && ismember(app.StateDropDown.Value, app.StateDropDown.Items) ...
                    && ismember(app.CityDropDown.Value, app.CityDropDown.Items)

                % Obtain the appropriate information needed to plot graph
                % and then update graph
                obtainLatitudeAndLongitudeAndDayNumber(app, app.StateDropDown.Value, app.CityDropDown.Value);
                updateGraph(app);
            end
        end
    end

    methods (Access = private)

        function obtainLatitudeAndLongitudeAndDayNumber(app, state, city)

            % check entire databaseCities
            for i=1:height(app.databaseCities)

                % if chosen city and state match in databaseCities,
                % retrieve their respective latitude and longitudes
                if isequal(char(city),char(app.databaseCities(i,1))) ...
                        && isequal(char(state), char(app.databaseCities(i,2)))
                    latitude = app.databaseCities(i,3);
                    longitude = app.databaseCities(i,4);
                end
            end

            % Month to int conversions
            if app.MonthDropDown.Value == "January"
                MonthValue = 0; % 0 days have passed prior to January
            elseif app.MonthDropDown.Value == "February"
                MonthValue = 31; % 31 days in January
            elseif app.MonthDropDown.Value == "March"
                MonthValue = (31 + 28); % 28 days in February if not Leap Year
            elseif app.MonthDropDown.Value == "April"
                MonthValue = (31 + 28 + 31); % 31 days in March
            elseif app.MonthDropDown.Value == "May"
                MonthValue = (31 + 28 + 31 + 30); % 30 days in April
            elseif app.MonthDropDown.Value == "June"
                MonthValue = (31 + 28 + 31 + 30 + 31); % 31 days in May
            elseif app.MonthDropDown.Value == "July"
                MonthValue = (31 + 28 + 31 + 30 + 31 + 30); % 30 days in June
            elseif app.MonthDropDown.Value == "August"
                MonthValue = (31 + 28 + 31 + 30 + 31 + 30 + 31); % 31 days in July
            elseif app.MonthDropDown.Value == "September"
                MonthValue = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 30); % 30 days in August
            elseif app.MonthDropDown.Value == "October"
                MonthValue = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 30 + 31); % 31 days om September
            elseif app.MonthDropDown.Value == "November"
                MonthValue = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 30 + 31 + 30); % 30 days in October
            elseif app.MonthDropDown.Value == "December"
                MonthValue = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 30 + 31 + 30 + 31); % 31 days in November
            end
            % if it is leap year and month chosen is after february (where the
            % extra day occurs), add one day
            if (rem(app.YearDropDown.Value, 4) == 0) & (app.MonthDropDown.Value ~= "January" ...
                    & app.MonthDropDown.Value ~= "February")
                MonthValue = MonthValue + 1;
            end
            % add day selected to the number of days from chosen month
            DayNumber = MonthValue + str2double(app.DayDropDown.Value); % converting the string value from day selected to a double
            % every time we call for laitude, longitude, and day, we need
            % to caluclate the sunrise and sunset next, so I am calling the
            % function here
            calculateSunriseAndSunset(app,latitude,longitude,DayNumber);
        end
    end

    methods (Access = private)

        % the days displayed in the drop down change depending on the
        % year and month selected
        function updateDays(app, selectedYear, selectedMonth)


            % check how many days in month/year
            years = [""]; % initialize years as a string array

            % check if selectedYear is divisible by 4 to determine if leap year
            if rem(str2double(selectedYear), 4) == 0 & selectedMonth == "February"
                for i=1:29 % days in feb during leap year
                    years(i) = num2str(i);
                end
            elseif selectedMonth == "February"
                for i=1:28 % days in feb if not leap year
                    years(i) = num2str(i);
                end
            elseif selectedMonth == "January" || selectedMonth == "March" || selectedMonth == "May" ...
                    || selectedMonth == "July" || selectedMonth == "September" || selectedMonth == "November"
                for i=1:31 % days in months above
                    years(i) = num2str(i);
                end
            elseif selectedMonth == "April" || selectedMonth == "June" || selectedMonth == "August" ...
                    || selectedMonth == "October" || selectedMonth == "December"
                for i=1:30 % days in months above
                    years(i) = num2str(i);
                end
            end
            app.DayDropDown.Items = years;
        end
    end

    methods (Access = private)

        function calculateSunriseAndSunset(app,latitude, longitude, dayNumber)
            % need fractionalYear for equation of time and declination angle
            fractionalYear = ((2*pi)/365)*(dayNumber - 1.5); % in radians
            % need equation of time and decl angle for hour of angle
            % sunrise and sunset and sunrise and sunset
            eqtime = 229.18*(0.000075 + 0.001868*cos(fractionalYear) - 0.032077*sin(fractionalYear) ...
                - 0.014615*cos(2*fractionalYear) - 0.040849*sin(2*fractionalYear));
            decl = 0.006918 - 0.399912*cos(fractionalYear) + 0.070257*sin(fractionalYear) - 0.006758*cos(2*fractionalYear) ...
                + 0.000907*sin(2*fractionalYear) - 0.002697*cos(3*fractionalYear) + 0.00148*sin(3*fractionalYear);
            % need latitude and longitude for hour of angle sunrise and
            % sunset and sunrise and sunset
            latitude = cell2mat(latitude); % converting cell array to ordinary array
            longitude = cell2mat(longitude);

            % need hour of angle sunrise and sunset for sunrise and sunset
            % calculations
            hourAngleSunrise = acosd((cosd(90.833)/(cosd(latitude)*cos(decl)) - tand(latitude)*tan(decl)));
            hourAngleSunset = -acosd((cosd(90.833)/(cosd(latitude)*cos(decl)) - tand(latitude)*tan(decl)));

            app.sunrise = 420 - 4*(longitude + hourAngleSunrise) - eqtime; % in min
            app.sunset = 420 - 4*(longitude + hourAngleSunset) - eqtime; % in min

            % solar time is the time between sunrise and sunset
            app.solarTime = app.sunset - app.sunrise;
            % 0 to pi radians are the angles we are able to see the sun
            app.ang_vel = (abs(hourAngleSunset - hourAngleSunrise))/app.solarTime; % in deg/min
            app.ang_vel = app.ang_vel * 0.01745; % in rad/min
        end
    end

    methods (Access = private)
        function updateGraph(app)
            timeOfDay = [1:app.sunset];
            timeInHours = timeOfDay./60;
            angleOfSun = zeros(size(timeOfDay));

            for (i = 1:max(timeOfDay))
                if (i > app.sunrise && i < app.sunset)
                    angleOfSun(i) = (i-app.sunrise)*app.ang_vel;
                else
                    angleOfSun(i) = 0;
                end
            end

            plot(app.UIAxes3, timeInHours, angleOfSun);

            % display sunrise and sunset in hrs
            app.TextArea_Sunrise.Value =int2str(app.sunrise/60);
            app.TextArea_Sunset.Value = int2str(app.sunset/60);
        end
    end


    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 640 480];
            app.UIFigure.Name = 'MATLAB App';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [1 1 640 480];

            % Create IntrotabandexplanationTab
            app.IntrotabandexplanationTab = uitab(app.TabGroup);
            app.IntrotabandexplanationTab.Title = 'Intro tab and explanation';
            app.IntrotabandexplanationTab.BackgroundColor = [1 1 0.0667];
            app.IntrotabandexplanationTab.ForegroundColor = [0 0 1];

            % Create TextArea
            app.TextArea = uitextarea(app.IntrotabandexplanationTab);
            app.TextArea.FontColor = [1 0 0];
            app.TextArea.Position = [35 35 583 360];
            app.TextArea.Value = {'Carson Denbina: Are solar panels right for you?'; ''; 'The goal of my tab is to provide users with information over whether or not they should get solar panels due to economic circumstances. In this version of my code I have found information from 4 popular solar panel companies about their 60 panel models and 72 panel models. I have 2 different line graphs with data that gives a best fit line for price vs wattage and price vs size of solar panels. These lines of best fit provide an average that the user can use to see what panels go over the average and what panels are under the average. In the future I want to add labels to each point on the graph to provide the user with more information on what company they should go with. '; ''; 'Alex Daquinag: Solar PV installation per country'; ''; 'This  the total installed cost per kilowatt based on the material of solar panels chosen as well as the region selected by the user. Users can select the country they want to inquire information about through a drop down menu and the total costs of services will be formatted in a bar graph manner. By presenting the data in this way, I aim to answer the questions: How does the region of installation affect the cost of solar implementation? Which material minimizes or maximizes these costs?'; ''; 'Gladwin Mathew: Annual  utility-scale PV capacity by module and/or mounting type'; ''; 'My tab is giving the user information on the annual capacity utility-scale PV capacity(GWAC) from different tilts and films, through 2010-2022 there are 8 types intotal each will be show as a bar graph. The tab will show the difference over the years of use of different types of solar panels and show which ones perform the best.'; ''; 'Remi Lokhandwala: Angle of Solar Panel vs. Time of Day'; ''; 'My tab acts as a visual calculator for the optimal angle the user’s solar panel should be faced. When given appropriate information, my tab displays the angle in degrees and radians. It relates to the group topic because the more direct sunlight the panel receives, the more efficient it will be.'; ''; ''; ''; ''; ''};

            % Create TextArea_3
            app.TextArea_3 = uitextarea(app.IntrotabandexplanationTab);
            app.TextArea_3.HorizontalAlignment = 'center';
            app.TextArea_3.FontName = 'Century Gothic';
            app.TextArea_3.FontSize = 30;
            app.TextArea_3.FontColor = [0 0 1];
            app.TextArea_3.Position = [104 394 446 52];
            app.TextArea_3.Value = {' Economizing Solar Energy'};

            % Create AresolarpanelsrightforyouTab
            app.AresolarpanelsrightforyouTab = uitab(app.TabGroup);
            app.AresolarpanelsrightforyouTab.Title = 'Are solar panels right for you? ';
            app.AresolarpanelsrightforyouTab.BackgroundColor = [0.6588 0.7294 0.7176];
            app.AresolarpanelsrightforyouTab.ForegroundColor = [0 0 1];

            % Create UIAxes
            app.UIAxes = uiaxes(app.AresolarpanelsrightforyouTab);
            title(app.UIAxes, 'Are solar panels right for you ')
            xlabel(app.UIAxes, 'Solar panel price ')
            ylabel(app.UIAxes, 'Solar panel size and energy ')
            zlabel(app.UIAxes, 'Z')
            app.UIAxes.Position = [75 180 475 215];

            % Create FormulaForLineofBestFitTextArea_2Label
            app.FormulaForLineofBestFitTextArea_2Label = uilabel(app.AresolarpanelsrightforyouTab);
            app.FormulaForLineofBestFitTextArea_2Label.HorizontalAlignment = 'right';
            app.FormulaForLineofBestFitTextArea_2Label.Position = [175 408 154 22];
            app.FormulaForLineofBestFitTextArea_2Label.Text = 'Formula For Line of Best Fit';

            % Create FormulaForLineofBestFitTextArea_2
            app.FormulaForLineofBestFitTextArea_2 = uitextarea(app.AresolarpanelsrightforyouTab);
            app.FormulaForLineofBestFitTextArea_2.ValueChangedFcn = createCallbackFcn(app, @DropDownValueChanged, true);
            app.FormulaForLineofBestFitTextArea_2.ValueChangingFcn = createCallbackFcn(app, @DropDownValueChanged, true);
            app.FormulaForLineofBestFitTextArea_2.Position = [344 408 150 24];

            % Create Image2_2
            app.Image2_2 = uiimage(app.AresolarpanelsrightforyouTab);
            app.Image2_2.Position = [175 3 316 184];
            app.Image2_2.ImageSource = 'Screenshot 2023-11-30 at 12.14.08 PM.png';

            % Create PlotThisTableButton_2
            app.PlotThisTableButton_2 = uibutton(app.AresolarpanelsrightforyouTab, 'push');
            app.PlotThisTableButton_2.ButtonPushedFcn = createCallbackFcn(app, @PlotDataButtonPushed, true);
            app.PlotThisTableButton_2.Position = [47 80 110 23];
            app.PlotThisTableButton_2.Text = 'Plot This Table-->';

            % Create DropDown_3
            app.DropDown_3 = uidropdown(app.AresolarpanelsrightforyouTab);
            app.DropDown_3.Items = {'Select Option', 'price vs size', 'price vs wattage'};
            app.DropDown_3.DropDownOpeningFcn = createCallbackFcn(app, @DropDownValueChanged, true);
            app.DropDown_3.ValueChangedFcn = createCallbackFcn(app, @DropDownValueChanged, true);
            app.DropDown_3.ClickedFcn = createCallbackFcn(app, @DropDownValueChanged, true);
            app.DropDown_3.Position = [502 80 100 22];
            app.DropDown_3.Value = 'Select Option';

            % Create SolarPVinstallationcostpercountryTab
            app.SolarPVinstallationcostpercountryTab = uitab(app.TabGroup);
            app.SolarPVinstallationcostpercountryTab.Title = 'Solar PV installation cost per country';
            app.SolarPVinstallationcostpercountryTab.BackgroundColor = [0.6588 0.7294 0.7176];
            app.SolarPVinstallationcostpercountryTab.ForegroundColor = [0 0 1];

            % Create UIAxes2
            app.UIAxes2 = uiaxes(app.SolarPVinstallationcostpercountryTab);
            title(app.UIAxes2, 'Total Solar PV Installation Cost')
            xlabel(app.UIAxes2, ' ')
            ylabel(app.UIAxes2, 'USD/kW')
            zlabel(app.UIAxes2, 'Z')
            app.UIAxes2.Position = [47 112 537 321];

            % Create SelectCountryDropDownLabel
            app.SelectCountryDropDownLabel = uilabel(app.SolarPVinstallationcostpercountryTab);
            app.SelectCountryDropDownLabel.HorizontalAlignment = 'right';
            app.SelectCountryDropDownLabel.Position = [69 35 84 22];
            app.SelectCountryDropDownLabel.Text = 'Select Country';

            % Create SelectCountryDropDown
            app.SelectCountryDropDown = uidropdown(app.SolarPVinstallationcostpercountryTab);
            app.SelectCountryDropDown.Items = {'SELECT', 'United States', 'Russian Federation', 'Japan', 'Canada', 'South Africa', 'Argentina', 'United Kingdom'};
            app.SelectCountryDropDown.ValueChangedFcn = createCallbackFcn(app, @SelectCountryDropDownValueChanged, true);
            app.SelectCountryDropDown.Position = [168 35 100 22];
            app.SelectCountryDropDown.Value = 'SELECT';

            % Create DisplayMinButton
            app.DisplayMinButton = uibutton(app.SolarPVinstallationcostpercountryTab, 'push');
            app.DisplayMinButton.ButtonPushedFcn = createCallbackFcn(app, @DisplayMinButtonPushed, true);
            app.DisplayMinButton.Position = [418 58 100 23];
            app.DisplayMinButton.Text = 'Display Min';

            % Create DisplayMaxButton
            app.DisplayMaxButton = uibutton(app.SolarPVinstallationcostpercountryTab, 'push');
            app.DisplayMaxButton.ButtonPushedFcn = createCallbackFcn(app, @DisplayMaxButtonPushed, true);
            app.DisplayMaxButton.Position = [417 25 100 23];
            app.DisplayMaxButton.Text = 'Display Max';

            % Create AnnualUitilityScalePVcapacityTab
            app.AnnualUitilityScalePVcapacityTab = uitab(app.TabGroup);
            app.AnnualUitilityScalePVcapacityTab.Title = 'Annual Uitility Scale PV capacity';
            app.AnnualUitilityScalePVcapacityTab.BackgroundColor = [0.6588 0.7294 0.7176];
            app.AnnualUitilityScalePVcapacityTab.ForegroundColor = [0 0 1];

            % Create UIAxes_2
            app.UIAxes_2 = uiaxes(app.AnnualUitilityScalePVcapacityTab);
            title(app.UIAxes_2, 'Annual  utility-scale PV capacity by module and/or mounting type')
            xlabel(app.UIAxes_2, {'Installation Year'; ''; ''})
            ylabel(app.UIAxes_2, 'Annual Capacity Additions (GWAC)')
            zlabel(app.UIAxes_2, 'Z')
            app.UIAxes_2.FontName = 'Century Gothic';
            app.UIAxes_2.FontWeight = 'bold';
            app.UIAxes_2.XColor = [1 0 0];
            app.UIAxes_2.XTick = [0 0.2 0.4 0.6 0.8 1];
            app.UIAxes_2.YColor = [0 0 1];
            app.UIAxes_2.GridColor = [1 0 0];
            app.UIAxes_2.XGrid = 'on';
            app.UIAxes_2.YGrid = 'on';
            app.UIAxes_2.FontSize = 10;
            app.UIAxes_2.Position = [60 112 534 312];

            % Create PlotavgAnnualCapacityButton
            app.PlotavgAnnualCapacityButton = uibutton(app.AnnualUitilityScalePVcapacityTab, 'push');
            app.PlotavgAnnualCapacityButton.ButtonPushedFcn = createCallbackFcn(app, @PlotavgAnnualCapacityButtonPushed, true);
            app.PlotavgAnnualCapacityButton.BackgroundColor = [1 1 1];
            app.PlotavgAnnualCapacityButton.Position = [70 69 169 53];
            app.PlotavgAnnualCapacityButton.Text = 'Plot avg. Annual Capacity';

            % Create SelectModuleandormountingtypeDropDownLabel
            app.SelectModuleandormountingtypeDropDownLabel = uilabel(app.AnnualUitilityScalePVcapacityTab);
            app.SelectModuleandormountingtypeDropDownLabel.HorizontalAlignment = 'right';
            app.SelectModuleandormountingtypeDropDownLabel.FontColor = [0 0 1];
            app.SelectModuleandormountingtypeDropDownLabel.Position = [265 80 198 31];
            app.SelectModuleandormountingtypeDropDownLabel.Text = 'Select Module and/or mounting type';

            % Create SelectModuleandormountingtypeDropDown
            app.SelectModuleandormountingtypeDropDown = uidropdown(app.AnnualUitilityScalePVcapacityTab);
            app.SelectModuleandormountingtypeDropDown.Items = {'Type:', 'Total Tracking', 'Total c-Si', 'Total Thin-Film', 'Total Fixed-Tilt', 'Tracking Thin-Film', 'Tracking c-Si', 'Fixed-Tilt Thin-Film', 'Fixed-Tilt c-Si'};
            app.SelectModuleandormountingtypeDropDown.ValueChangedFcn = createCallbackFcn(app, @typeSelected, true);
            app.SelectModuleandormountingtypeDropDown.FontColor = [0 0 1];
            app.SelectModuleandormountingtypeDropDown.Position = [478 80 100 31];
            app.SelectModuleandormountingtypeDropDown.Value = 'Type:';

            % Create AngleofSolarPanelvsTimeofDayTab
            app.AngleofSolarPanelvsTimeofDayTab = uitab(app.TabGroup);
            app.AngleofSolarPanelvsTimeofDayTab.Title = 'Angle of Solar Panel vs. Time of Day';
            app.AngleofSolarPanelvsTimeofDayTab.BackgroundColor = [0.6588 0.7294 0.7176];
            app.AngleofSolarPanelvsTimeofDayTab.ForegroundColor = [0 0 1];

            % Create UIAxes3
            app.UIAxes3 = uiaxes(app.AngleofSolarPanelvsTimeofDayTab);
            title(app.UIAxes3, 'Angle of Solar Panel vs. Time of Day')
            xlabel(app.UIAxes3, 'Time of Day [hours]')
            ylabel(app.UIAxes3, 'Angle [rad]')
            zlabel(app.UIAxes3, 'Z')
            app.UIAxes3.Position = [279 230 300 185];
            xticks(app.UIAxes3, [0 3 6 9 12 15 18 21 24]); % 0:24:3 hours
            yticks(app.UIAxes3, [pi/4 pi/2 3*pi/4 pi]);


            % Create StateDropDownLabel
            app.StateDropDownLabel = uilabel(app.AngleofSolarPanelvsTimeofDayTab);
            app.StateDropDownLabel.HorizontalAlignment = 'right';
            app.StateDropDownLabel.Position = [58 274 65 22];
            app.StateDropDownLabel.Text = 'State';

            % Create StateDropDown
            app.StateDropDown = uidropdown(app.AngleofSolarPanelvsTimeofDayTab, 'Editable','on'); % user can type
            app.StateDropDown.Items = app.databaseStates(:,1); % items are all the states included in databaseStates
            app.StateDropDown.Value = '';
            app.StateDropDown.Position = [138 274 100 22];
            app.StateDropDown.ValueChangedFcn = createCallbackFcn(app, @StateDropDownValueChanged, true);


            % Create CityDropDownLabel
            app.CityDropDownLabel = uilabel(app.AngleofSolarPanelvsTimeofDayTab);
            app.CityDropDownLabel.HorizontalAlignment = 'right';
            app.CityDropDownLabel.Position = [97 230 26 22];
            app.CityDropDownLabel.Text = 'City';



            % Create CityDropDown
            app.CityDropDown = uidropdown(app.AngleofSolarPanelvsTimeofDayTab, 'Editable','on');
            app.CityDropDown.Items = {''};
            app.CityDropDown.Value = '';
            app.CityDropDown.Position = [138 230 100 22];
            app.CityDropDown.Value = '';
            app.CityDropDown.ValueChangedFcn = createCallbackFcn(app, @CityDropDownValueChanged, true);



            % Create YearDropDownLabel
            app.YearDropDownLabel = uilabel(app.AngleofSolarPanelvsTimeofDayTab);
            app.YearDropDownLabel.HorizontalAlignment = 'right';
            app.YearDropDownLabel.Position = [58 406 65 22];
            app.YearDropDownLabel.Text = 'Year';

            % Create YearDropDown
            app.YearDropDown = uidropdown(app.AngleofSolarPanelvsTimeofDayTab, 'Editable','on');

            % items in YearDropDown are 1900 to 2100
            j = 1900;
            years = [""]; % initializing years as an empty string array
            for i=1:200
                years(i) = num2str(j);
                j = j+1;
            end
            app.YearDropDown.Items = years;
            app.YearDropDown.Value = '';
            app.YearDropDown.Position = [138 406 100 22];
            app.YearDropDown.ValueChangedFcn = createCallbackFcn(app, @YearDropDownValueChanged, true);



            % Create MonthDropDownLabel
            app.MonthDropDownLabel = uilabel(app.AngleofSolarPanelvsTimeofDayTab);
            app.MonthDropDownLabel.HorizontalAlignment = 'right';
            app.MonthDropDownLabel.Position = [58 362 65 22];
            app.MonthDropDownLabel.Text = 'Month';

            % Create MonthDropDown
            app.MonthDropDown = uidropdown(app.AngleofSolarPanelvsTimeofDayTab, 'Editable','on');
            % month itmes are months of year
            app.MonthDropDown.Items = ["January" "February" "March" "April" "May" "June" "July" ...
                "August" "September" "October" "November" "December"];
            app.MonthDropDown.Value = '';
            app.MonthDropDown.Position = [138 362 100 22];
            app.MonthDropDown.ValueChangedFcn = createCallbackFcn(app, @MonthDropDownValueChanged, true);



            % Create DayDropDownLabel
            app.DayDropDownLabel = uilabel(app.AngleofSolarPanelvsTimeofDayTab);
            app.DayDropDownLabel.HorizontalAlignment = 'right';
            app.DayDropDownLabel.Position = [58 318 65 22];
            app.DayDropDownLabel.Text = 'Day';

            % Create DayDropDown
            app.DayDropDown = uidropdown(app.AngleofSolarPanelvsTimeofDayTab, 'Editable','on');
            app.DayDropDown.Items = {''};
            app.DayDropDown.Value = '';
            app.DayDropDown.Value = '';
            app.DayDropDown.Position = [138 318 100 22];
            app.DayDropDown.ValueChangedFcn = createCallbackFcn(app, @DayDropDownValueChanged, true);

            % Create TextArea_Sunrise_Label
            app.TextArea_Sunrise_Label = uilabel(app.AngleofSolarPanelvsTimeofDayTab);
            app.TextArea_Sunrise_Label.HorizontalAlignment = 'right';
            app.TextArea_Sunrise_Label.Position = [343 169 55 22];
            app.TextArea_Sunrise_Label.Text = 'Sunrise: ';

            % Create TextArea_Sunrise
            app.TextArea_Sunrise = uitextarea(app.AngleofSolarPanelvsTimeofDayTab);
            app.TextArea_Sunrise.Position = [413 169 100 22];
            app.TextArea_Sunrise.Enable = 'Off';

            % Create TextArea_Sunset_Label
            app.TextArea_Sunset_Label = uilabel(app.AngleofSolarPanelvsTimeofDayTab);
            app.TextArea_Sunset_Label.HorizontalAlignment = 'right';
            app.TextArea_Sunset_Label.Position = [338 120 55 22];
            app.TextArea_Sunset_Label.Text = 'Sunset: ';

            % Create TextArea_Sunset
            app.TextArea_Sunset = uitextarea(app.AngleofSolarPanelvsTimeofDayTab);
            app.TextArea_Sunset.Position = [413 120 100 22];

            app.TextArea_Sunset.Enable = 'Off';



            % Create citationsTab
            app.citationsTab = uitab(app.TabGroup);
            app.citationsTab.Title = 'citations';
            app.citationsTab.BackgroundColor = [0.6588 0.7294 0.7176];
            app.citationsTab.ForegroundColor = [0 0 1];

            % Create TextArea_2
            app.TextArea_2 = uitextarea(app.citationsTab);
            app.TextArea_2.Position = [22 14 596 432];
            app.TextArea_2.Value = {'Tab 1:'; '“Trina Solar, TSM-NE09RC.05, 415W Bifacial PV Module, PV Wire 1100mm (~43"), MC-4 EVO2 Connector, 30mm Black Frame with Black Back-Sheet, BOB, 144 1/3 Cell, 25A Fuse, 1500VDC, 390.5 PTC, 25/25 Warranty.” 2023. Inverter Supply. 2023. https://www.invertersupply.com/index.php?main_page=product_info&products_id=203939&gad_source=1&gclid=Cj0KCQiA3uGqBhDdARIsAFeJ5r1QXlpJ2jqaCvm9nSFjJLWvBdiJIKQUd9uY7rqBYLFjVNMmPq1NFrYaAukVEALw_wcB.'; ''; '2023. Greensideenergy.com. 2023. https://www.greensideenergy.com/solar/jinko-solar-320w-120-half-cell-mono-blkblk-1000v-solar-panel-jkm320m-60hbl.'; ''; '‌“Solar Panels for Sale | Buy Solar Panel Online - A1 Solar Store.” 2023. A1SolarStore. 2023. https://a1solarstore.com/solar-panels.html.'; ''; '‌“405 Watt Jinko Mono XL Solar Panel.” 2023. SunWatts. 2023. https://sunwatts.com/405-watt-jinko-mono-xl-solar-panel/?gclid=Cj0KCQiA3uGqBhDdARIsAFeJ5r1j8NAuvf4fFKLHE2R1B_6-Dk4yZI32z-uHBKqvbDYZOw-2jRADk9caAomwEALw_wcB.'; ''; 'Almerini, Ana. 2022. “Complete Guide to Solar Panel Size.” Solar Reviews. Solar Reviews. December 19, 2022. https://www.solarreviews.com/blog/complete-guide-to-solar-panel-size.'; ''; '‌“Hanwha Q CELLS Q.PEAK-DUO-Lme Solar -G7.3-400 400Watt 144 1/2 Cells BoW.” 2023. Solar Cellz USA. 2023. https://store.solarcellzusa.com/HANWHA-Q-CELLS-Q.PEAK-DUO-L-G7.3-400-400W-CLEAR-ON-WHITE-144-HALF-CELL-MONO-SOLAR-PANEL?gclid=Cj0KCQiA3uGqBhDdARIsAFeJ5r1J6Ye9JF9CqE3XfZQt4ZszQYAP18lFyw2gDW-JdMQfjYcP8J7VPFEaAkUiEALw_wcB.'; ''; '‌LONGI. 2018. “LONGI 455W Solar Panel 144 Cell LR4-72HPH-455M - A1SolarStore.” A1solarstore.com. 2018. https://ca.a1solarstore.com/solar-panels/longi-455w-solar-panel-144-cell-lr4-72hph-455m-en/.'; ''; '‌I used a lot of third party sources for finding prices. In the final verion I want to find more first hand prices and information. '; ''; 'Tab 2 Alex:'; ''; 'IRENA (2020), Renewable Power Generation Costs in 2019, International Renewable Energy Agency, Abu Dhabi.'; 'https://www.irena.org/publications/2020/Jun/Renewable-Power-Costs-in-2019'; ''; 'Tab 3 Gladwin:'; ''; 'Lawrence Berkeley National Lab. (2023). Utility-Scale Solar, 2023 Edition: Analysis of Empirical Plant-level Data from U.S. Ground-mounted PV, PV+battery, and CSP Plants (exceeding 5 MWAC) [data set].  Retrieved from https://dx.doi.org/10.25984/2006993.'; ''; 'Tab 4 Remi'; '‌'; 'NOAA Global Monitoring Division. “General Solar Position Calculations.” https://gml.noaa.gov/grad/solcalc/solareqns.PDF'; ''; 'simplemaps. “United States Cities Database.” November 12, 2023. https://simplemaps.com/data/us-cities'; ''; '‌'};

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end

    end
    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = project_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end